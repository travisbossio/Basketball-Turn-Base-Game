﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the bandit enemy class
    /// </summary>
    class Bandit : Enemy
    {
        /// <summary>
        /// initializes bandit character with following stats
        /// </summary>
        public Bandit()
        {
            this.health = 100;
            this.speed = 25;
            this.physicalDefense = 10;
            this.magicDefense = 10;
            this.strength = 30;
            this.intelligence = 15;
            this.Name = "Bandit";
            this.isEnemy = true;
            this.DisplayName = "Evil Point Guard";
        }
    }
}
