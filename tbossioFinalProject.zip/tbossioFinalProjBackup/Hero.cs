﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// hero class that inherits from unit class and is parent to heros
    /// </summary>
    class Hero : Unit
    {
        protected int skill;
        protected string skillDisplay;

        // default constructor
        public Hero()
        {
        }

        public int Skill { get => skill; set => skill = value; }
        public string SkillDisplay { get => skillDisplay; set => skillDisplay = value; }
    }
}
