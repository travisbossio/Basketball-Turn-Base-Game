﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the warrior hero class
    /// </summary>
    class Warrior : Hero
    {
        /// <summary>
        /// initializes warrior character with following stats
        /// </summary>
        public Warrior()
        {
            this.health = 100;
            this.speed = 50;
            this.physicalDefense = 20;
            this.magicDefense = 10;
            this.strength = 35;
            this.intelligence = 15;
            this.skill = 25;
            this.Name = "Warrior";
            this.isEnemy = false;
            this.ListLocation = 1;
            this.DisplayName = "Uncle Drew";
        }

        /// <summary>
        /// overriden special attack for warrior
        /// auto minus 25 hit points to enemy
        /// </summary>
        /// <param name="target"></param>
        public override string Special(Unit target)
        {
            target.Health = target.Health - this.skill;
            target.DefendEnabled = false;

            return $"{this.DisplayName} posterized {target.DisplayName}!!!";
        }
    }
}
