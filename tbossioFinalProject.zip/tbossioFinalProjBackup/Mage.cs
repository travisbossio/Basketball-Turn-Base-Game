﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the mage hero class
    /// </summary>
    class Mage : Hero
    {
        /// <summary>
        /// initializes mage character with following stats
        /// </summary>
        public Mage()
        {
            this.health = 100;
            this.speed = 25;
            this.physicalDefense = 10;
            this.magicDefense = 20;
            this.strength = 15;
            this.intelligence = 35;
            this.skill = 25;
            this.Name = "Mage";
            this.isEnemy = false;
            this.ListLocation = 2;
            this.DisplayName = "Melo";
        }

        /// <summary>
        /// overriden special method for mage
        /// halves enemy
        /// </summary>
        /// <param name="target"></param>
        public override string Special(Unit target)
        {
            target.Health = target.Health / 2;
            target.DefendEnabled = false;

            return $"{this.DisplayName} broke {target.DisplayName} ankles!!!";
        }

        
    }
}
