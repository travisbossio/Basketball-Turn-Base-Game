﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the dragon enemy class
    /// </summary>
    class Dragon : Enemy
    {
        /// <summary>
        /// initializes dragon character with following stats
        /// </summary>
        public Dragon()
        {
            this.health = 100;
            this.speed = 99;
            this.physicalDefense = 15;
            this.magicDefense = 15;
            this.strength = 30;
            this.intelligence = 30;
            this.Name = "Dragon";
            this.isEnemy = true;
            this.DisplayName = "Evil Shooting Guard";
        }

        /// <summary>
        /// overriden magic method for dragon
        /// dragon ignores if a unit defends
        /// </summary>
        /// <param name="target"></param>
        public override void Magic(Unit target)
        {
            target.Health = target.Health - ((intelligence - target.MagicDefense + 10) / 2);
            target.DefendEnabled = false;
        }

        /// <summary>
        /// overriden attack method for dragon
        /// dragon ignores if a unit defends
        /// </summary>
        /// <param name="target"></param>
        public override void Attack(Unit target)
        {
            // if block enabled halves the damage taken
            if (target.DefendEnabled)
            {
                target.Health = target.Health - ((strength - target.PhysicalDefense + 10) / 2);
            }
            else
            {
                target.Health = target.Health - (strength - target.PhysicalDefense + 10);
            }
            target.DefendEnabled = false;
        }
    }
}
