﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tbossioFinalProject
{
    /// <summary>
    /// This is the GUI form which handles all the buttons and controls
    /// of the game
    /// </summary>
    public partial class Dungeon : Form
    {
        GameLogic game = new GameLogic();

        /// <summary>
        /// Initialize Game setup
        /// </summary>
        public Dungeon()
        {          
            InitializeComponent();
            displayFeed.AppendText("This is the battle log");
            SetButtons();
            SetAttackList();
            DisplayBattleOrder();
            RefreshInfo();
            SetEnemyDisplay();
        }

        /// <summary>
        /// Refreshes unit health after each turn
        /// Refreshes buttons
        /// </summary>
        public void RefreshInfo()
        {
            SetHeroSkillPicture();
            UpdateHealths();
            SetAttackList();
            if (game.attackList.Count <= game.currentTurn)
            {
                displayFeed.AppendText($"\r\nIt is {game.attackList[0].DisplayName} turn");
            }
            else
            {
                displayFeed.AppendText($"\r\nIt is {game.attackList[game.currentTurn].DisplayName} turn");
            }
        }

        /// <summary>
        /// Method that exits game
        /// </summary>
        public void GameOver()
        {
            System.Environment.Exit(1);
        }

        #region GUI Methods

        /// <summary>
        /// when attack/heal button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AttackButton_Click(object sender, EventArgs e)
        {
            MakeInitialButtonsInvisible();
            physAttackButton.Visible = true;
            magicAttackButton.Visible = true;
            healButton.Visible = true;

        }

        /// <summary>
        /// method for displaying battle order to feed
        /// </summary>
        private void DisplayBattleOrder()
        {
            displayFeed.AppendText("\r\nTurn Order:");

            // displays each unit from list
            foreach (var unit in game.attackList)
            {
                displayFeed.AppendText($"\r\n{unit.DisplayName}");
            }
        }

        /// <summary>
        /// method for setting heroes skill picture
        /// heroes share one skill point
        /// </summary>
        private void SetHeroSkillPicture()
        {
            // if hero skill full
            if (game.skillCount > 2)
            {
                skillButton.Enabled = true;
                heroSkill1.BackgroundImage = Properties.Resources.pixil_frame_0;
                heroSkill2.BackgroundImage = Properties.Resources.pixil_frame_0;
                heroSkill3.BackgroundImage = Properties.Resources.pixil_frame_0;
            }
            else
            {
                skillButton.Enabled = false;
                heroSkill1.BackgroundImage = null;
                heroSkill2.BackgroundImage = null;
                heroSkill3.BackgroundImage = null;
            }
        }

        /// <summary>
        /// method for removing enemy Picture
        /// </summary>
        private void RemoveEnemyPicture()
        {
            // remove bottom enemy picture
            if (game.enemyList[0].Health <= 0)
            {
                enemyPicture3.Visible = false;
                panel12.Visible = false;
            }
            // remove middle enemy picture
            for (int i = 0; i < game.enemyList.Count; i++)
            {
                // check if middle enemy
                if (game.enemyList[i].Health <= 0 && game.enemyList[i].ListLocation == 1)
                {
                    enemyPicture2.Visible = false;
                    panel10.Visible = false;
                }
            }
            // remove top enemy picture
            for (int i = 0; i < game.enemyList.Count; i++)
            {
                // check if top enemy
                if (game.enemyList[i].Health <= 0 && game.enemyList[i].ListLocation == 2)
                {
                    enemyPicture1.Visible = false;
                    panel8.Visible = false;
                }
            }
        }

        /// <summary>
        /// method for removing hero Picture
        /// </summary>
        private void RemoveHeroPicture()
        {
            // remove top hero picture
            for (int i = 0; i < game.heroList.Count; i++)
            {
                if (game.heroList[i].Health <= 0 && game.heroList[i].ListLocation == 0)
                {
                    heroPicture1.Visible = false;
                    panel5.Visible = false;
                }
            }
            // remove middle hero picture
            for (int i = 0; i < game.heroList.Count; i++)
            {
                // check if middle hero
                if (game.heroList[i].Health <= 0 && game.heroList[i].ListLocation == 1)
                {
                    heroPicture2.Visible = false;
                    panel6.Visible = false;
                }
            }
            // remove bottom hero picture
            for (int i = 0; i < game.heroList.Count; i++)
            {
                // check if bottom hero
                if (game.heroList[i].Health <= 0 && game.heroList[i].ListLocation == 2)
                {
                    heroPicture3.Visible = false;
                    panel7.Visible = false;
                }
            }
        }

        #endregion

        #region File Methods

        /// <summary>
        /// Method for writing lifetime stats to a file
        /// </summary>
        public void WriteRecords()
        {

            // opens file for reading
            StreamReader reader = new StreamReader("LifetimeStats.csv");
            try
            {
                // while file not empty
                while (!reader.EndOfStream)
                {
                    // read line of file into array seperating comma
                    var values = reader.ReadLine().Split(',');

                    // get stats from file
                    game.recordLevel = int.Parse(values[0]);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                reader.Close();
            }

            // open file writer
            StreamWriter writer = new StreamWriter("LifetimeStats.csv");
            try
            {
                // if new high score write to file
                if (game.recordLevel < game.levelCount)
                {
                    game.recordLevel = game.levelCount;
                }
                // write stats to csv file
                writer.WriteLine($"{game.recordLevel}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                writer.Close();
            }
        }
        #endregion

        #region Events

        /// <summary>
        /// event that is triggered when defend button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnDefendClick(object sender, EventArgs e)
        {
            MakeButtonsInvisible();
            EnableHeroClick();
            game.attackType = "defend";
        }

        /// <summary>
        /// event that is triggered when heal button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnHealClick(object sender, EventArgs e)
        {
            MakeButtonsInvisible();
            EnableHeroClick();
            game.attackType = "heal";
        }

        /// <summary>
        /// When skill button is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnSkillClick(object sender, EventArgs e)
        {
            // if last unit in the attack list
            if (game.currentTurn == game.attackList.Count - 1)
            {
                displayFeed.AppendText($"\r\n{game.attackList[0].DisplayName} chose skill select target carefully!");
            }
            else
            {
                displayFeed.AppendText($"\r\n{game.attackList[game.currentTurn].DisplayName} chose skill select target carefully!");
            }

            MakeButtonsInvisible();
            EnableEnemyClick();
            EnableHeroClick();
            game.attackType = "special";
            game.skillCount = 0;
        }

        /// <summary>
        /// When physical attack button is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnAttackClick(object sender, EventArgs e)
        {
            MakeButtonsInvisible();
            EnableEnemyClick();
            game.attackType = "attack";
        }
        /// <summary>
        /// when magic button is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnMagicClick(object sender, EventArgs e)
        {
            MakeButtonsInvisible();
            EnableEnemyClick();
            game.attackType = "magic";
        }

        /// <summary>
        /// whenever the bottom target enemy is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnTargetClick3(object sender, EventArgs e)
        {
            SetAttackList();
            // target the first enemy in list
            game.enemyTarget = 0;
            TargetClickLoop();
        }

        /// <summary>
        /// whenever the middle target enemy is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnTargetClick2(object sender, EventArgs e)
        {
            SetAttackList();
            // if two or more enemies in list target middle
            if (game.enemyList.Count >= 2)
            {
                // if bottom enemy disabled
                if (enemyPicture3.Visible == false)
                {
                    game.enemyTarget = 0;
                }
                else
                {
                    game.enemyTarget = 1;
                }
            }
            // else target first
            else
            {
                game.enemyTarget = 0;
            }
            TargetClickLoop();
        }

        /// <summary>
        /// whenever the top target enemy is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnTargetClick1(object sender, EventArgs e)
        {
            SetAttackList();
            // if three enemies in list target last
            if (game.enemyList.Count == 3)
            {
                game.enemyTarget = 2;
            }
            // if two enemies target last
            else if (game.enemyList.Count == 2)
            {
                game.enemyTarget = 1;
            }
            // if only one enemy target first
            else if (game.enemyList.Count == 1)
            {
                game.enemyTarget = 0;
            }
            TargetClickLoop();
        }

        /// <summary>
        /// whenever the top hero is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnHeroClick1(object sender, EventArgs e)
        {
            SetAttackList();
            // save hero attack
            string heroAttack = game.attackType;
            // attack hero if enemy turn
            EnemyTurnLoop();
            game.attackType = heroAttack;
            // cleric will always be the first in hero list
            displayFeed.AppendText($"\r\n{game.TakeTurn(game.heroList[0])}");
            DefaultButtonVisibility();
            MakeUnitTransparent();
            ChangeTurn();
            IncreaseSkillPoints();
            RefreshInfo();
        }

        /// <summary>
        /// whenever the middle hero is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnHeroClick2(object sender, EventArgs e)
        {
            SetAttackList();
            string heroAttack = game.attackType;
            // attack hero if enemy turn
            EnemyTurnLoop();
            game.attackType = heroAttack;
            // finds middle hero aka warrior
            DoHeroActionOnHero(1);
            DefaultButtonVisibility();
            MakeUnitTransparent();
            ChangeTurn();
            IncreaseSkillPoints();
            RefreshInfo();
        }

        /// <summary>
        /// whenever the bottom hero is clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void OnHeroClick3(object sender, EventArgs e)
        {
            SetAttackList();
            string heroAttack = game.attackType;
            // attack hero if enemy turn
            EnemyTurnLoop();
            game.attackType = heroAttack;
            // do hero action on mage
            DoHeroActionOnHero(2);
            DefaultButtonVisibility();
            MakeUnitTransparent();
            ChangeTurn();
            IncreaseSkillPoints();
            RefreshInfo();
        }
        #endregion

        #region Helpers

        /// <summary>
        /// method for performing the loop of a targeted enemy
        /// </summary>
        private void TargetClickLoop()
        {
            // save hero attack
            string heroAttack = game.attackType;
            // attack hero if enemy turn
            EnemyTurnLoop();
            game.attackType = heroAttack;
            displayFeed.AppendText($"\r\n{game.TakeTurn(game.enemyList[game.enemyTarget])}");
            DefaultButtonVisibility();
            MakeUnitTransparent();
            ChangeTurn();
            IncreaseSkillPoints();
            RefreshInfo();
        }

        /// <summary>
        /// method for iterating through attack list for enemies turn
        /// </summary>
        private void EnemyTurnLoop()
        {
            // while still enemy turn
            while (game.attackList[game.currentTurn].IsEnemy == true)
            {
                ChooseRandomHero();
                // if current enemy is dragon
                if (game.attackList[game.currentTurn].Name == "Dragon")
                {
                    RandomDragonMove();
                    TakeEnemyTurn();
                }
                else
                {
                    RandomOgreBanditMove();
                    TakeEnemyTurn();
                }
                UpdateHealths();
                ChangeTurn();
            }
        }

        /// <summary>
        /// method for enemies to choose a hero target from hero list
        /// </summary>
        private void ChooseRandomHero()
        {
            Random rand = new Random();
            // chooses hero based on how many heroes are left
            switch (game.heroList.Count)
            {
                case 3:
                    game.heroTarget = rand.Next(0, 3);
                    break;
                case 2:
                    game.heroTarget = rand.Next(0, 2);
                    break;
                case 1:
                    game.heroTarget = 0;
                    break;
            }
        }

        /// <summary>
        /// method for increasing skill points after each move
        /// </summary>
        private void IncreaseSkillPoints()
        {
            game.skillCount += 1;
        }

        /// <summary>
        /// method for taking an enemies turn
        /// </summary>
        private void TakeEnemyTurn()
        {
            if (game.heroList.Count >= 1)
            {
                if (game.attackType == "defend")
                {
                    displayFeed.AppendText($"\r\n{game.TakeTurn(game.attackList[game.currentTurn])}");
                }
                else
                {
                    displayFeed.AppendText($"\r\n{game.TakeTurn(game.heroList[game.heroTarget])}");
                }
            }
        }

        /// <summary>
        /// method that has enemy randomly picks attack or defend
        /// only for ogre and bandit
        /// </summary>
        public void RandomOgreBanditMove()
        {
            Random rand = new Random();
            int choice = rand.Next(0, 4);
            // enemy has a 25% chance of blocking
            if (choice == 3)
            {
                game.attackType = "defend";
            }
            else
            {
                game.attackType = "attack";
            }
        }
        /// <summary>
        /// method that has enemy randomly picks attack, defend or magic
        /// dragon is more likeley to defend
        /// </summary>
        public void RandomDragonMove()
        {
            Random rand = new Random();
            int choice = rand.Next(0, 5);
            // enemy has a 25% chance of blocking
            if (choice == 4)
            {
                game.attackType = "defend";
            }
            else if (choice == 3 || choice == 2)
            {
                game.attackType = "attack";
            }
            else if (choice == 1 || choice == 0)
            {
                game.attackType = "magic";
            }
        }

        /// <summary>
        /// method for performing a hero move onto another hero
        /// </summary>
        private void DoHeroActionOnHero(int heroListIndex)
        {
            for (int i = 0; i < game.heroList.Count; i++)
            {
                if (game.heroList[i].ListLocation == heroListIndex)
                {
                    displayFeed.AppendText($"\r\n{game.TakeTurn(game.heroList[i])}");
                }
            }
        }


        /// <summary>
        /// method for chagning the turn
        /// </summary>
        private void ChangeTurn()
        {
            if (game.currentTurn >= game.attackList.Count - 1)
            {
                game.currentTurn = 0;
            }
            else
            {
                game.currentTurn += 1;
            }
        }

        /// <summary>
        /// method for checking health of heroes and determining if they are dead
        /// </summary>
        public void CheckHeroDeaths()
        {
            RemoveHeroPicture();
            for (int i = 0; i < game.heroList.Count; i++)
            {
                if (game.heroList[i].Health <= 0)
                {
                    game.heroList.RemoveAt(i);
                }
            }

            if (game.heroList.Count == 0)
            {
                MessageBox.Show($"You Lost!\nYou made it to level {game.levelCount}");
                WriteRecords();
                GameOver();
            }
        }

        /// <summary>
        /// method for checking health of units and determining if they are dead
        /// </summary>
        public void CheckEnemyDeaths()
        {
            for (int i = 0; i < game.enemyList.Count; i++)
            {
                if (game.enemyList[i].Health <= 0)
                {
                    switch (game.enemyList[i].Name)
                    {
                        case "Bandit":
                            displayFeed.AppendText("\r\nYou defeated an Evil Point Guard!");
                            break;
                        case "Ogre":
                            displayFeed.AppendText("\r\nYou defeated an Evil Center!");
                            break;
                        case "Dragon":
                            displayFeed.AppendText("\r\nYou defeated an Evil Shooting guard!");
                            break;
                    }
                    RemoveEnemyPicture();
                    game.enemyList.RemoveAt(i);
                }
            }

            if (game.enemyList.Count == 0)
            {
                MessageBox.Show($"You beat {game.levelCount}!\nOn to the next!");
                game.levelCount += 1;
                game.spawnEnemies();
                SetEnemyDisplay();
                UpdateHealths();
                SetAttackList();
                DisplayBattleOrder();
            }
        }

        /// <summary>
        /// method for making buttons invisible
        /// attack, heal, and magic
        /// </summary>
        private void MakeButtonsInvisible()
        {
            MakeInitialButtonsInvisible();
            label7.Visible = true;
            physAttackButton.Visible = false;
            magicAttackButton.Visible = false;
            healButton.Visible = false;
        }

        /// <summary>
        /// method for making units backcolor transparent after targeting
        /// </summary>
        private void MakeUnitTransparent()
        {
            enemyPicture3.BackColor = Color.Transparent;
            enemyPicture2.BackColor = Color.Transparent;
            enemyPicture1.BackColor = Color.Transparent;
            heroPicture1.BackColor = Color.Transparent;
            heroPicture2.BackColor = Color.Transparent;
            heroPicture3.BackColor = Color.Transparent;
        }

        /// <summary>
        /// method for setting default buttons visibility
        /// </summary>
        private void DefaultButtonVisibility()
        {
            enemyPicture3.Enabled = false;
            enemyPicture2.Enabled = false;
            enemyPicture3.Enabled = false;
            heroPicture1.Enabled = false;
            heroPicture2.Enabled = false;
            heroPicture3.Enabled = false;
            attackButton.Visible = true;
            defendButton.Visible = true;
            label7.Visible = false;
            skillButton.Visible = true;
            attackButton.Enabled = true;
            skillButton.Enabled = true;
        }

        /// <summary>
        /// method that enables targeting of heroes
        /// </summary>
        private void EnableHeroClick()
        {
            heroPicture1.Enabled = true;
            heroPicture1.BackColor = Color.Red;
            heroPicture2.Enabled = true;
            heroPicture2.BackColor = Color.Red;
            heroPicture3.Enabled = true;
            heroPicture3.BackColor = Color.Red;
        }

        /// <summary>
        /// method that enables targeting of enemies
        /// </summary>
        private void EnableEnemyClick()
        {
            enemyPicture1.Enabled = true;
            enemyPicture1.BackColor = Color.Red;
            enemyPicture2.Enabled = true;
            enemyPicture2.BackColor = Color.Red;
            enemyPicture3.Enabled = true;
            enemyPicture3.BackColor = Color.Red;
        }

        /// <summary>
        /// method for updating unit healths
        /// </summary>
        private void UpdateHealths()
        {
            UpdateEnemyHealth();
            UpdateHeroHealth();
            CheckEnemyDeaths();
            CheckHeroDeaths();
            SetAttackList();
        }

        /// <summary>
        /// method for update enemy health in GUI
        /// </summary>
        private void UpdateEnemyHealth()
        {
            // if three enemies remain
            if (game.enemyList.Count == 3)
            {
                enemyHealth3.Text = game.enemyList[0].Health.ToString();
                enemyBar3.Value = HealthReturnEnemies(0);
                enemyHealth2.Text = game.enemyList[1].Health.ToString();
                enemyBar2.Value = HealthReturnEnemies(1);
                enemyHealth1.Text = game.enemyList[2].Health.ToString();
                enemyBar1.Value = HealthReturnEnemies(2);
            }
            // if two enemies remain
            else if (game.enemyList.Count == 2)
            {
                // if bottom enemies left
                if (game.enemyList[0].ListLocation == 0 && game.enemyList[1].ListLocation == 1)
                {
                    enemyHealth3.Text = game.enemyList[0].Health.ToString();
                    enemyBar3.Value = HealthReturnEnemies(0);
                    enemyHealth2.Text = game.enemyList[1].Health.ToString();
                    enemyBar2.Value = HealthReturnEnemies(1);
                }
                // if first and third enemy left
                else if (game.enemyList[0].ListLocation == 0 && game.enemyList[1].ListLocation == 2)
                {
                    enemyHealth3.Text = game.enemyList[0].Health.ToString();
                    enemyBar3.Value = HealthReturnEnemies(0);
                    enemyHealth1.Text = game.enemyList[1].Health.ToString();
                    enemyBar1.Value = HealthReturnEnemies(1);
                }
                // if top two enemy left
                else if (game.enemyList[0].ListLocation == 1 && game.enemyList[1].ListLocation == 2)
                {
                    enemyHealth2.Text = game.enemyList[0].Health.ToString();
                    enemyBar2.Value = HealthReturnEnemies(0);
                    enemyHealth1.Text = game.enemyList[1].Health.ToString();
                    enemyBar1.Value = HealthReturnEnemies(1);
                }
            }
            // if only one enemy remains
            else if (game.enemyList.Count == 1)
            {
                // if first enemy left
                if (game.enemyList[0].ListLocation == 0)
                {
                    enemyHealth3.Text = game.enemyList[0].Health.ToString();
                    enemyBar3.Value = HealthReturnEnemies(0);
                }
                // if second enemy left
                else if (game.enemyList[0].ListLocation == 1)
                {
                    enemyHealth2.Text = game.enemyList[0].Health.ToString();
                    enemyBar2.Value = HealthReturnEnemies(0);
                }
                // if second enemy left
                else if (game.enemyList[0].ListLocation == 2)
                {
                    enemyHealth1.Text = game.enemyList[0].Health.ToString();
                    enemyBar1.Value = HealthReturnEnemies(0);
                }
            }
        }

        /// <summary>
        /// method for update hero health in GUI
        /// </summary>
        private void UpdateHeroHealth()
        {
            // if three heroes remain
            if (game.heroList.Count == 3)
            {
                heroHealth3.Text = game.heroList[2].Health.ToString();
                heroBar3.Value = HealthReturnHeroes(2);
                heroHealth2.Text = game.heroList[1].Health.ToString();
                heroBar2.Value = HealthReturnHeroes(1);
                heroHealth1.Text = game.heroList[0].Health.ToString();
                heroBar1.Value = HealthReturnHeroes(0);
            }
            // if two heroes remain
            else if (game.heroList.Count == 2)
            {
                // if top two heroes
                if (game.heroList[0].ListLocation == 0 && game.heroList[1].ListLocation == 1)
                {
                    heroHealth1.Text = game.heroList[0].Health.ToString();
                    heroBar1.Value = HealthReturnHeroes(0);
                    heroHealth2.Text = game.heroList[1].Health.ToString();
                    heroBar2.Value = HealthReturnHeroes(1);
                }
                // if first and third hero left
                else if (game.heroList[0].ListLocation == 0 && game.heroList[1].ListLocation == 2)
                {
                    heroHealth3.Text = game.heroList[1].Health.ToString();
                    heroBar3.Value = HealthReturnHeroes(1);
                    heroHealth1.Text = game.heroList[0].Health.ToString();
                    heroBar1.Value = HealthReturnHeroes(0);
                }
                // if bottm heroes left
                else if (game.heroList[0].ListLocation == 1 && game.heroList[1].ListLocation == 2)
                {
                    heroHealth2.Text = game.heroList[0].Health.ToString();
                    heroBar2.Value = HealthReturnHeroes(0);
                    heroHealth3.Text = game.heroList[1].Health.ToString();
                    heroBar3.Value = HealthReturnHeroes(1);
                }
            }
            // if only one hero remains
            else if (game.heroList.Count == 1)
            {
                // if top hero left
                if (game.heroList[0].ListLocation == 0)
                {
                    heroHealth1.Text = game.heroList[0].Health.ToString();
                    heroBar1.Value = HealthReturnHeroes(0);
                }
                // if middle hero left
                else if (game.heroList[0].ListLocation == 1)
                {
                    heroHealth2.Text = game.heroList[0].Health.ToString();
                    heroBar2.Value = HealthReturnHeroes(0);
                }
                // if bottom hero left
                else if (game.heroList[0].ListLocation == 2)
                {
                    heroHealth3.Text = game.heroList[0].Health.ToString();
                    heroBar3.Value = HealthReturnHeroes(0);
                }
            }
        }

        /// <summary>
        /// method that returns hero health
        /// will always return 0 to 100
        /// </summary>
        /// <param name="unit"></param>
        private int HealthReturnHeroes(int index)
        {
           
            // if unit health in upper region
            if (game.heroList[index].Health >= 50)
            {
                // if health greater than 100 return 100
                return game.heroList[index].Health > 100 ? 100 : game.heroList[index].Health;
            }
            else
            {
                // if health less than 0 return 0
                return game.heroList[index].Health < 0 ? 0 : game.heroList[index].Health;            
            }
        }

        /// <summary>
        /// method that returns unit health
        /// will always return 0 to 100
        /// </summary>
        /// <param name="unit"></param>
        private int HealthReturnEnemies(int index)
        {

            // if unit health in upper region
            if (game.enemyList[index].Health >= 50)
            {
                // if health greater than 100 return 100
                return game.enemyList[index].Health > 100 ? 100 : game.enemyList[index].Health;
            }
            else
            {
                // if health less than 0 return 0
                return game.enemyList[index].Health < 0 ? 0 : game.enemyList[index].Health;
            }
        }

        /// <summary>
        /// method that makes skill, attack, and defend buttons invisible
        /// </summary>
        private void MakeInitialButtonsInvisible()
        {
            attackButton.Visible = false;
            skillButton.Visible = false;
            defendButton.Visible = false;
        }
        #endregion

        #region Menu Methods

        /// <summary>
        /// method for showing lifetime stats
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LifetimeStatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // opens file for reading
            StreamReader reader = new StreamReader("LifetimeStats.csv");
            try
            {
                // while file not empty
                while (!reader.EndOfStream)
                {
                    // read line of file into array seperating comma
                    var values = reader.ReadLine().Split(',');


                    // display lifetime stats
                    MessageBox.Show($"Record Level: {values[0]}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                reader.Close();
            }
        }

        /// <summary>
        /// method for exitting the form on user request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExitGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GameOver();
        }

        /// <summary>
        /// method for restarting form on user request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RestartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        /// <summary>
        /// method for showing user the instructions of the game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InstructionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The rules of the game as follows:\n" +
                "This game is a battle of stamina and attrition.\n" +
                "Player spawns with three heroes that are capable of attacking, defending, and healing.\n" +
                "The player will encounter random enemies each level.\n" +
                "The player will use their skills and strategy to defeat the enemies and move to the next level.\n" +
                "It is important to pay attention to the turn order as it is key to knowing which action to perform on which unit.\n" +
                "Good luck and have fun!" + "\nRemember this:\nUncle Drew likes to dunk\nMelo likes to shoot\nCurry likes to motivate");
        }

        /// <summary>
        /// method that displays about user page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Author: Travis Bossio\nDate: 12/16/2021\nClass: CS 3020 001");
        }
        #endregion

        #region Setup 


        /// <summary>
        /// method for setting attack list
        /// </summary>
        public void SetAttackList()
        {
            game.attackList.Clear();
            // adds each enemy to attacking list
            foreach (var enemy in game.enemyList)
            {
                game.attackList.Add(enemy);
            }
            // adds each hero to attacking list
            foreach (var hero in game.heroList)
            {
                game.attackList.Add(hero);
            }

            // order attack list by speed
            game.attackList = (from unit in game.attackList
                               orderby unit.Speed descending
                               select unit).ToList();
        }


        /// <summary>
        /// method for starting the game by setting button events
        /// </summary>
        public void SetButtons()
        {
            heroPicture1.Enabled = false;
            enemyPicture3.Enabled = false;
            enemyPicture2.Enabled = false;
            enemyPicture1.Enabled = false;
            enemyPicture1.Click += new EventHandler(OnTargetClick1);
            enemyPicture2.Click += new EventHandler(OnTargetClick2);
            enemyPicture3.Click += new EventHandler(OnTargetClick3);
            heroPicture1.Click += new EventHandler(OnHeroClick1);
            heroPicture2.Click += new EventHandler(OnHeroClick2);
            heroPicture3.Click += new EventHandler(OnHeroClick3);
            physAttackButton.Click += new EventHandler(OnAttackClick);
            magicAttackButton.Click += new EventHandler(OnMagicClick);
            skillButton.Click += new EventHandler(OnSkillClick);
            healButton.Click += new EventHandler(OnHealClick);
            defendButton.Click += new EventHandler(OnDefendClick);

        }

        /// <summary>
        /// method for setting the enemies display on GUI
        /// </summary>
        private void SetEnemyDisplay()
        {
            enemyPicture3.Visible = true;
            panel12.Visible = true;
            switch (game.enemyList[0].Name)
            {
                case "Dragon":
                    enemyPicture3.Image = Properties.Resources.SG;
                    break;
                case "Ogre":
                    enemyPicture3.Image = Properties.Resources.Center;
                    break;
                case "Bandit":
                    enemyPicture3.Image = Properties.Resources.PG;
                    break;
            }

            if (game.enemyList.Count > 1)
            {
                enemyPicture2.Visible = true;
                panel10.Visible = true;
                switch (game.enemyList[1].Name)
                {
                    case "Dragon":
                        enemyPicture2.Image = Properties.Resources.SG;
                        break;
                    case "Ogre":
                        enemyPicture2.Image = Properties.Resources.Center;
                        break;
                    case "Bandit":
                        enemyPicture2.Image = Properties.Resources.PG;
                        break;
                }
            }
            else
            {
                enemyPicture2.Visible = false;
                panel10.Visible = false;
            }

            if (game.enemyList.Count > 2)
            {
                enemyPicture1.Visible = true;
                panel8.Visible = true;
                switch (game.enemyList[2].Name)
                {
                    case "Dragon":
                        enemyPicture1.Image = Properties.Resources.SG;
                        break;
                    case "Ogre":
                        enemyPicture1.Image = Properties.Resources.Center;
                        break;
                    case "Bandit":
                        enemyPicture1.Image = Properties.Resources.SG;
                        break;
                }
            }
            else
            {
                enemyPicture1.Visible = false;
                panel8.Visible = false;
            }
        }

        #endregion
    }
}
