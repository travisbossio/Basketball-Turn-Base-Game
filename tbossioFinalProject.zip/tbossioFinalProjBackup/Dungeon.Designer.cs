﻿
namespace tbossioFinalProject
{
    partial class Dungeon
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dungeon));
            this.heroPicture2 = new System.Windows.Forms.PictureBox();
            this.heroPicture3 = new System.Windows.Forms.PictureBox();
            this.heroBar1 = new System.Windows.Forms.ProgressBar();
            this.displayFeed = new System.Windows.Forms.TextBox();
            this.heroPicture1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.enemyHealth3 = new System.Windows.Forms.Label();
            this.enemyBar3 = new System.Windows.Forms.ProgressBar();
            this.panel10 = new System.Windows.Forms.Panel();
            this.enemyHealth2 = new System.Windows.Forms.Label();
            this.enemyBar2 = new System.Windows.Forms.ProgressBar();
            this.panel8 = new System.Windows.Forms.Panel();
            this.enemyHealth1 = new System.Windows.Forms.Label();
            this.enemyBar1 = new System.Windows.Forms.ProgressBar();
            this.panel7 = new System.Windows.Forms.Panel();
            this.heroSkill3 = new System.Windows.Forms.Panel();
            this.heroHealth3 = new System.Windows.Forms.Label();
            this.heroBar3 = new System.Windows.Forms.ProgressBar();
            this.panel6 = new System.Windows.Forms.Panel();
            this.heroSkill2 = new System.Windows.Forms.Panel();
            this.heroHealth2 = new System.Windows.Forms.Label();
            this.heroBar2 = new System.Windows.Forms.ProgressBar();
            this.panel5 = new System.Windows.Forms.Panel();
            this.heroSkill1 = new System.Windows.Forms.Panel();
            this.heroHealth1 = new System.Windows.Forms.Label();
            this.healButton = new System.Windows.Forms.Button();
            this.magicAttackButton = new System.Windows.Forms.Button();
            this.physAttackButton = new System.Windows.Forms.Button();
            this.enemyPicture3 = new System.Windows.Forms.PictureBox();
            this.enemyPicture2 = new System.Windows.Forms.PictureBox();
            this.enemyPicture1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instructionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statisticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lifetimeStatsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4 = new System.Windows.Forms.Panel();
            this.defendButton = new System.Windows.Forms.Button();
            this.attackButton = new System.Windows.Forms.Button();
            this.skillButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // heroPicture2
            // 
            this.heroPicture2.BackColor = System.Drawing.Color.Transparent;
            this.heroPicture2.Image = ((System.Drawing.Image)(resources.GetObject("heroPicture2.Image")));
            this.heroPicture2.Location = new System.Drawing.Point(287, 177);
            this.heroPicture2.Name = "heroPicture2";
            this.heroPicture2.Size = new System.Drawing.Size(143, 129);
            this.heroPicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.heroPicture2.TabIndex = 1;
            this.heroPicture2.TabStop = false;
            // 
            // heroPicture3
            // 
            this.heroPicture3.BackColor = System.Drawing.Color.Transparent;
            this.heroPicture3.Image = global::tbossioFinalProject.Properties.Resources.Melo;
            this.heroPicture3.Location = new System.Drawing.Point(307, 312);
            this.heroPicture3.Name = "heroPicture3";
            this.heroPicture3.Size = new System.Drawing.Size(143, 129);
            this.heroPicture3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heroPicture3.TabIndex = 2;
            this.heroPicture3.TabStop = false;
            // 
            // heroBar1
            // 
            this.heroBar1.BackColor = System.Drawing.SystemColors.Control;
            this.heroBar1.Cursor = System.Windows.Forms.Cursors.Default;
            this.heroBar1.ForeColor = System.Drawing.Color.LightBlue;
            this.heroBar1.Location = new System.Drawing.Point(81, 7);
            this.heroBar1.Name = "heroBar1";
            this.heroBar1.Size = new System.Drawing.Size(112, 24);
            this.heroBar1.TabIndex = 0;
            this.heroBar1.Value = 100;
            // 
            // displayFeed
            // 
            this.displayFeed.Location = new System.Drawing.Point(634, 2);
            this.displayFeed.Multiline = true;
            this.displayFeed.Name = "displayFeed";
            this.displayFeed.ReadOnly = true;
            this.displayFeed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.displayFeed.Size = new System.Drawing.Size(484, 170);
            this.displayFeed.TabIndex = 4;
            // 
            // heroPicture1
            // 
            this.heroPicture1.BackColor = System.Drawing.Color.Transparent;
            this.heroPicture1.Image = global::tbossioFinalProject.Properties.Resources.Jordan1;
            this.heroPicture1.Location = new System.Drawing.Point(319, 58);
            this.heroPicture1.Name = "heroPicture1";
            this.heroPicture1.Size = new System.Drawing.Size(111, 105);
            this.heroPicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heroPicture1.TabIndex = 0;
            this.heroPicture1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(-4, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(0, 0);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackgroundImage = global::tbossioFinalProject.Properties.Resources.PikesPeak;
            this.panel2.Location = new System.Drawing.Point(2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(0, 0);
            this.panel2.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = global::tbossioFinalProject.Properties.Resources._20180207_017;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.healButton);
            this.panel3.Controls.Add(this.magicAttackButton);
            this.panel3.Controls.Add(this.physAttackButton);
            this.panel3.Controls.Add(this.enemyPicture3);
            this.panel3.Controls.Add(this.enemyPicture2);
            this.panel3.Controls.Add(this.enemyPicture1);
            this.panel3.Controls.Add(this.heroPicture1);
            this.panel3.Controls.Add(this.heroPicture2);
            this.panel3.Controls.Add(this.heroPicture3);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.menuStrip1);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1154, 642);
            this.panel3.TabIndex = 12;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Gray;
            this.panel12.Controls.Add(this.enemyHealth3);
            this.panel12.Controls.Add(this.enemyBar3);
            this.panel12.Location = new System.Drawing.Point(882, 367);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(250, 40);
            this.panel12.TabIndex = 33;
            // 
            // enemyHealth3
            // 
            this.enemyHealth3.AutoSize = true;
            this.enemyHealth3.BackColor = System.Drawing.Color.Gray;
            this.enemyHealth3.ForeColor = System.Drawing.Color.White;
            this.enemyHealth3.Location = new System.Drawing.Point(168, 5);
            this.enemyHealth3.Name = "enemyHealth3";
            this.enemyHealth3.Size = new System.Drawing.Size(42, 25);
            this.enemyHealth3.TabIndex = 26;
            this.enemyHealth3.Text = "100";
            // 
            // enemyBar3
            // 
            this.enemyBar3.BackColor = System.Drawing.SystemColors.Control;
            this.enemyBar3.Cursor = System.Windows.Forms.Cursors.Default;
            this.enemyBar3.ForeColor = System.Drawing.Color.LightBlue;
            this.enemyBar3.Location = new System.Drawing.Point(50, 6);
            this.enemyBar3.Name = "enemyBar3";
            this.enemyBar3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.enemyBar3.RightToLeftLayout = true;
            this.enemyBar3.Size = new System.Drawing.Size(112, 24);
            this.enemyBar3.TabIndex = 0;
            this.enemyBar3.Value = 100;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gray;
            this.panel10.Controls.Add(this.enemyHealth2);
            this.panel10.Controls.Add(this.enemyBar2);
            this.panel10.Location = new System.Drawing.Point(882, 221);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(250, 40);
            this.panel10.TabIndex = 32;
            // 
            // enemyHealth2
            // 
            this.enemyHealth2.AutoSize = true;
            this.enemyHealth2.BackColor = System.Drawing.Color.Gray;
            this.enemyHealth2.ForeColor = System.Drawing.Color.White;
            this.enemyHealth2.Location = new System.Drawing.Point(168, 5);
            this.enemyHealth2.Name = "enemyHealth2";
            this.enemyHealth2.Size = new System.Drawing.Size(42, 25);
            this.enemyHealth2.TabIndex = 26;
            this.enemyHealth2.Text = "100";
            // 
            // enemyBar2
            // 
            this.enemyBar2.BackColor = System.Drawing.SystemColors.Control;
            this.enemyBar2.Cursor = System.Windows.Forms.Cursors.Default;
            this.enemyBar2.ForeColor = System.Drawing.Color.LightBlue;
            this.enemyBar2.Location = new System.Drawing.Point(50, 6);
            this.enemyBar2.Name = "enemyBar2";
            this.enemyBar2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.enemyBar2.RightToLeftLayout = true;
            this.enemyBar2.Size = new System.Drawing.Size(112, 24);
            this.enemyBar2.TabIndex = 0;
            this.enemyBar2.Value = 100;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gray;
            this.panel8.Controls.Add(this.enemyHealth1);
            this.panel8.Controls.Add(this.enemyBar1);
            this.panel8.Location = new System.Drawing.Point(882, 88);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(250, 40);
            this.panel8.TabIndex = 31;
            // 
            // enemyHealth1
            // 
            this.enemyHealth1.AutoSize = true;
            this.enemyHealth1.BackColor = System.Drawing.Color.Gray;
            this.enemyHealth1.ForeColor = System.Drawing.Color.White;
            this.enemyHealth1.Location = new System.Drawing.Point(168, 5);
            this.enemyHealth1.Name = "enemyHealth1";
            this.enemyHealth1.Size = new System.Drawing.Size(42, 25);
            this.enemyHealth1.TabIndex = 26;
            this.enemyHealth1.Text = "100";
            // 
            // enemyBar1
            // 
            this.enemyBar1.BackColor = System.Drawing.SystemColors.Control;
            this.enemyBar1.Cursor = System.Windows.Forms.Cursors.Default;
            this.enemyBar1.ForeColor = System.Drawing.Color.LightBlue;
            this.enemyBar1.Location = new System.Drawing.Point(50, 6);
            this.enemyBar1.Name = "enemyBar1";
            this.enemyBar1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.enemyBar1.RightToLeftLayout = true;
            this.enemyBar1.Size = new System.Drawing.Size(112, 24);
            this.enemyBar1.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gray;
            this.panel7.Controls.Add(this.heroSkill3);
            this.panel7.Controls.Add(this.heroHealth3);
            this.panel7.Controls.Add(this.heroBar3);
            this.panel7.Location = new System.Drawing.Point(51, 377);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(250, 40);
            this.panel7.TabIndex = 30;
            // 
            // heroSkill3
            // 
            this.heroSkill3.BackColor = System.Drawing.Color.White;
            this.heroSkill3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.heroSkill3.Location = new System.Drawing.Point(201, 7);
            this.heroSkill3.Name = "heroSkill3";
            this.heroSkill3.Size = new System.Drawing.Size(27, 23);
            this.heroSkill3.TabIndex = 27;
            // 
            // heroHealth3
            // 
            this.heroHealth3.AutoSize = true;
            this.heroHealth3.BackColor = System.Drawing.Color.Gray;
            this.heroHealth3.ForeColor = System.Drawing.Color.White;
            this.heroHealth3.Location = new System.Drawing.Point(6, 6);
            this.heroHealth3.Name = "heroHealth3";
            this.heroHealth3.Size = new System.Drawing.Size(42, 25);
            this.heroHealth3.TabIndex = 26;
            this.heroHealth3.Text = "100";
            // 
            // heroBar3
            // 
            this.heroBar3.BackColor = System.Drawing.SystemColors.Control;
            this.heroBar3.Cursor = System.Windows.Forms.Cursors.Default;
            this.heroBar3.ForeColor = System.Drawing.Color.LightBlue;
            this.heroBar3.Location = new System.Drawing.Point(81, 7);
            this.heroBar3.Name = "heroBar3";
            this.heroBar3.Size = new System.Drawing.Size(112, 24);
            this.heroBar3.TabIndex = 0;
            this.heroBar3.Value = 59;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gray;
            this.panel6.Controls.Add(this.heroSkill2);
            this.panel6.Controls.Add(this.heroHealth2);
            this.panel6.Controls.Add(this.heroBar2);
            this.panel6.Location = new System.Drawing.Point(31, 231);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(250, 40);
            this.panel6.TabIndex = 29;
            // 
            // heroSkill2
            // 
            this.heroSkill2.BackColor = System.Drawing.Color.White;
            this.heroSkill2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.heroSkill2.Location = new System.Drawing.Point(201, 7);
            this.heroSkill2.Name = "heroSkill2";
            this.heroSkill2.Size = new System.Drawing.Size(27, 23);
            this.heroSkill2.TabIndex = 27;
            // 
            // heroHealth2
            // 
            this.heroHealth2.AutoSize = true;
            this.heroHealth2.BackColor = System.Drawing.Color.Gray;
            this.heroHealth2.ForeColor = System.Drawing.Color.White;
            this.heroHealth2.Location = new System.Drawing.Point(6, 6);
            this.heroHealth2.Name = "heroHealth2";
            this.heroHealth2.Size = new System.Drawing.Size(42, 25);
            this.heroHealth2.TabIndex = 26;
            this.heroHealth2.Text = "100";
            // 
            // heroBar2
            // 
            this.heroBar2.BackColor = System.Drawing.SystemColors.Control;
            this.heroBar2.Cursor = System.Windows.Forms.Cursors.Default;
            this.heroBar2.ForeColor = System.Drawing.Color.LightBlue;
            this.heroBar2.Location = new System.Drawing.Point(81, 7);
            this.heroBar2.Name = "heroBar2";
            this.heroBar2.Size = new System.Drawing.Size(112, 24);
            this.heroBar2.TabIndex = 0;
            this.heroBar2.Value = 75;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gray;
            this.panel5.Controls.Add(this.heroSkill1);
            this.panel5.Controls.Add(this.heroHealth1);
            this.panel5.Controls.Add(this.heroBar1);
            this.panel5.Location = new System.Drawing.Point(63, 88);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(250, 40);
            this.panel5.TabIndex = 28;
            // 
            // heroSkill1
            // 
            this.heroSkill1.BackColor = System.Drawing.Color.White;
            this.heroSkill1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.heroSkill1.Location = new System.Drawing.Point(201, 7);
            this.heroSkill1.Name = "heroSkill1";
            this.heroSkill1.Size = new System.Drawing.Size(27, 23);
            this.heroSkill1.TabIndex = 27;
            // 
            // heroHealth1
            // 
            this.heroHealth1.AutoSize = true;
            this.heroHealth1.BackColor = System.Drawing.Color.Gray;
            this.heroHealth1.ForeColor = System.Drawing.Color.White;
            this.heroHealth1.Location = new System.Drawing.Point(6, 6);
            this.heroHealth1.Name = "heroHealth1";
            this.heroHealth1.Size = new System.Drawing.Size(42, 25);
            this.heroHealth1.TabIndex = 26;
            this.heroHealth1.Text = "100";
            // 
            // healButton
            // 
            this.healButton.BackColor = System.Drawing.Color.White;
            this.healButton.Location = new System.Drawing.Point(337, 587);
            this.healButton.Name = "healButton";
            this.healButton.Size = new System.Drawing.Size(177, 39);
            this.healButton.TabIndex = 23;
            this.healButton.Text = "Motivate";
            this.healButton.UseVisualStyleBackColor = false;
            this.healButton.Visible = false;
            // 
            // magicAttackButton
            // 
            this.magicAttackButton.BackColor = System.Drawing.Color.White;
            this.magicAttackButton.Location = new System.Drawing.Point(337, 532);
            this.magicAttackButton.Name = "magicAttackButton";
            this.magicAttackButton.Size = new System.Drawing.Size(177, 39);
            this.magicAttackButton.TabIndex = 22;
            this.magicAttackButton.Text = "Shoot";
            this.magicAttackButton.UseVisualStyleBackColor = false;
            this.magicAttackButton.Visible = false;
            // 
            // physAttackButton
            // 
            this.physAttackButton.BackColor = System.Drawing.Color.White;
            this.physAttackButton.Location = new System.Drawing.Point(337, 476);
            this.physAttackButton.Name = "physAttackButton";
            this.physAttackButton.Size = new System.Drawing.Size(177, 39);
            this.physAttackButton.TabIndex = 21;
            this.physAttackButton.Text = "Dunk";
            this.physAttackButton.UseVisualStyleBackColor = false;
            this.physAttackButton.Visible = false;
            // 
            // enemyPicture3
            // 
            this.enemyPicture3.BackColor = System.Drawing.Color.Transparent;
            this.enemyPicture3.Image = global::tbossioFinalProject.Properties.Resources.PG;
            this.enemyPicture3.Location = new System.Drawing.Point(713, 326);
            this.enemyPicture3.Name = "enemyPicture3";
            this.enemyPicture3.Size = new System.Drawing.Size(125, 124);
            this.enemyPicture3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPicture3.TabIndex = 12;
            this.enemyPicture3.TabStop = false;
            // 
            // enemyPicture2
            // 
            this.enemyPicture2.BackColor = System.Drawing.Color.Transparent;
            this.enemyPicture2.Image = global::tbossioFinalProject.Properties.Resources.SG;
            this.enemyPicture2.Location = new System.Drawing.Point(684, 186);
            this.enemyPicture2.Name = "enemyPicture2";
            this.enemyPicture2.Size = new System.Drawing.Size(154, 133);
            this.enemyPicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPicture2.TabIndex = 11;
            this.enemyPicture2.TabStop = false;
            // 
            // enemyPicture1
            // 
            this.enemyPicture1.BackColor = System.Drawing.Color.Transparent;
            this.enemyPicture1.Image = global::tbossioFinalProject.Properties.Resources.Center;
            this.enemyPicture1.Location = new System.Drawing.Point(713, 36);
            this.enemyPicture1.Name = "enemyPicture1";
            this.enemyPicture1.Size = new System.Drawing.Size(163, 144);
            this.enemyPicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPicture1.TabIndex = 10;
            this.enemyPicture1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(146, 539);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(275, 25);
            this.label7.TabIndex = 24;
            this.label7.Text = "Click Character To Preform Action";
            this.label7.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.statisticsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1154, 33);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.instructionsToolStripMenuItem,
            this.restartToolStripMenuItem,
            this.exitGameToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(74, 29);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(219, 34);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.AboutToolStripMenuItem_Click);
            // 
            // instructionsToolStripMenuItem
            // 
            this.instructionsToolStripMenuItem.Name = "instructionsToolStripMenuItem";
            this.instructionsToolStripMenuItem.Size = new System.Drawing.Size(219, 34);
            this.instructionsToolStripMenuItem.Text = "Instructions";
            this.instructionsToolStripMenuItem.Click += new System.EventHandler(this.InstructionsToolStripMenuItem_Click);
            // 
            // restartToolStripMenuItem
            // 
            this.restartToolStripMenuItem.Name = "restartToolStripMenuItem";
            this.restartToolStripMenuItem.Size = new System.Drawing.Size(219, 34);
            this.restartToolStripMenuItem.Text = "Restart Game";
            this.restartToolStripMenuItem.Click += new System.EventHandler(this.RestartToolStripMenuItem_Click);
            // 
            // exitGameToolStripMenuItem
            // 
            this.exitGameToolStripMenuItem.Name = "exitGameToolStripMenuItem";
            this.exitGameToolStripMenuItem.Size = new System.Drawing.Size(219, 34);
            this.exitGameToolStripMenuItem.Text = "Exit Game";
            this.exitGameToolStripMenuItem.Click += new System.EventHandler(this.ExitGameToolStripMenuItem_Click);
            // 
            // statisticsToolStripMenuItem
            // 
            this.statisticsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lifetimeStatsToolStripMenuItem});
            this.statisticsToolStripMenuItem.Name = "statisticsToolStripMenuItem";
            this.statisticsToolStripMenuItem.Size = new System.Drawing.Size(96, 29);
            this.statisticsToolStripMenuItem.Text = "Statistics";
            // 
            // lifetimeStatsToolStripMenuItem
            // 
            this.lifetimeStatsToolStripMenuItem.Name = "lifetimeStatsToolStripMenuItem";
            this.lifetimeStatsToolStripMenuItem.Size = new System.Drawing.Size(219, 34);
            this.lifetimeStatsToolStripMenuItem.Text = "Lifetime Stats";
            this.lifetimeStatsToolStripMenuItem.Click += new System.EventHandler(this.LifetimeStatsToolStripMenuItem_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkGray;
            this.panel4.Controls.Add(this.defendButton);
            this.panel4.Controls.Add(this.displayFeed);
            this.panel4.Controls.Add(this.attackButton);
            this.panel4.Controls.Add(this.skillButton);
            this.panel4.Location = new System.Drawing.Point(-1, 454);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1158, 188);
            this.panel4.TabIndex = 13;
            // 
            // defendButton
            // 
            this.defendButton.BackColor = System.Drawing.Color.White;
            this.defendButton.Location = new System.Drawing.Point(86, 78);
            this.defendButton.Name = "defendButton";
            this.defendButton.Size = new System.Drawing.Size(184, 39);
            this.defendButton.TabIndex = 21;
            this.defendButton.Text = "Defend";
            this.defendButton.UseVisualStyleBackColor = false;
            // 
            // attackButton
            // 
            this.attackButton.BackColor = System.Drawing.Color.White;
            this.attackButton.Location = new System.Drawing.Point(86, 22);
            this.attackButton.Name = "attackButton";
            this.attackButton.Size = new System.Drawing.Size(184, 39);
            this.attackButton.TabIndex = 19;
            this.attackButton.Text = "Attack/Heal";
            this.attackButton.UseVisualStyleBackColor = false;
            this.attackButton.Click += new System.EventHandler(this.AttackButton_Click);
            // 
            // skillButton
            // 
            this.skillButton.BackColor = System.Drawing.Color.White;
            this.skillButton.Location = new System.Drawing.Point(86, 133);
            this.skillButton.Name = "skillButton";
            this.skillButton.Size = new System.Drawing.Size(184, 39);
            this.skillButton.TabIndex = 20;
            this.skillButton.Text = "Skill";
            this.skillButton.UseVisualStyleBackColor = false;
            // 
            // Dungeon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 647);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dungeon";
            this.Text = "Dungeon";
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heroPicture1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPicture1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox heroPicture2;
        private System.Windows.Forms.PictureBox heroPicture3;
        private System.Windows.Forms.ProgressBar heroBar1;
        private System.Windows.Forms.TextBox displayFeed;
        private System.Windows.Forms.PictureBox heroPicture1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox enemyPicture3;
        private System.Windows.Forms.PictureBox enemyPicture2;
        private System.Windows.Forms.PictureBox enemyPicture1;
        private System.Windows.Forms.Button healButton;
        private System.Windows.Forms.Button magicAttackButton;
        private System.Windows.Forms.Button physAttackButton;
        private System.Windows.Forms.Button skillButton;
        private System.Windows.Forms.Button attackButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statisticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instructionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lifetimeStatsToolStripMenuItem;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label enemyHealth3;
        private System.Windows.Forms.ProgressBar enemyBar3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label enemyHealth2;
        private System.Windows.Forms.ProgressBar enemyBar2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label enemyHealth1;
        private System.Windows.Forms.ProgressBar enemyBar1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel heroSkill3;
        private System.Windows.Forms.Label heroHealth3;
        private System.Windows.Forms.ProgressBar heroBar3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel heroSkill2;
        private System.Windows.Forms.Label heroHealth2;
        private System.Windows.Forms.ProgressBar heroBar2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel heroSkill1;
        private System.Windows.Forms.Label heroHealth1;
        private System.Windows.Forms.Button defendButton;
    }
}

