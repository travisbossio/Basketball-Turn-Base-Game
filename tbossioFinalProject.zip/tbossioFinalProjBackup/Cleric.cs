﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the mage hero class
    /// </summary>
    class Cleric : Hero
    {
        /// <summary>
        /// initializes cleric character with following stats
        /// </summary>
        public Cleric()
        {
            this.health = 100;
            this.speed = 75;
            this.physicalDefense = 10;
            this.magicDefense = 10;
            this.strength = 25;
            this.intelligence = 25;
            this.skill = 25;
            this.Name = "Cleric";
            this.isEnemy = false;
            this.ListLocation = 0;
            this.DisplayName = "Curry";
        }

        /// <summary>
        /// overriden special method for cleric
        /// doubles teamates health
        /// </summary>
        /// <param name="target"></param>
        public override string Special(Unit target)
        {
            target.Health = target.Health + target.Health;
            target.DefendEnabled = false;

            return $"{this.DisplayName} really motivated {target.DisplayName}!!!";
        }

        /// <summary>
        /// overriden heal method for cleric
        /// gives 20 hp to target
        /// </summary>
        /// <param name="target"></param>
        public override void Heal(Unit target)
        {
            target.Health = target.Health + 20;
            target.DefendEnabled = false;
        }
    }
}
