﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
   /// <summary>
   /// This is the GameLogic class which handles most of the game logic
   /// outside the GUI
   /// </summary>
    class GameLogic
    {
        public List<Unit> attackList = new List<Unit>();
        public List<Unit> enemyList = new List<Unit>();
        public List<Unit> heroList = new List<Unit>();
        public string attackType;
        public int skillCount = 1;
        public int currentTurn = 0;
        public int enemyTarget = 0;
        public int heroTarget = 0;
        public int levelCount = 1;
        public int recordLevel;

        /// <summary>
        /// Constructor for gamelogic class
        /// </summary>
        public GameLogic()
        {
            spawnEnemies();
            spawnHeroes();
        }
    
        /// <summary>
        /// method for spawing random enemies into enemy list
        /// </summary>
        public void spawnEnemies()
        {
            int numEnemies;
            int enemyChoice;
            Random rand = new Random();

            numEnemies = rand.Next(1, 4);

            enemyList.Clear();

            // for each enemy add enemy to list randomly
            for (int i = 1; i <= numEnemies; i++)
            {
                enemyChoice = rand.Next(0, 3);
                switch (enemyChoice)
                {
                    case 0:
                        enemyList.Add(new Bandit());
                        enemyList[i - 1].ListLocation = i - 1;
                        break;
                    case 1:
                        enemyList.Add(new Ogre());
                        enemyList[i - 1].ListLocation = i - 1;
                        break;
                    case 2:
                        enemyList.Add(new Dragon());
                        enemyList[i - 1].ListLocation = i - 1;
                        break;
                }
            }

        }

        /// <summary>
        /// method for spawning heroes
        /// </summary>
        public void spawnHeroes()
        {
            heroList.Add(new Cleric());
            heroList.Add(new Warrior()); 
            heroList.Add(new Mage());
        }

        /// <summary>
        /// method for taking a units turn
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public string TakeTurn(Unit target)
        {

            switch (attackType)
            {
                case "attack":
                    // do dragon special attack
                    if (attackList[currentTurn].Name == "Dragon")
                    {
                        foreach (var hero in heroList)
                        {
                            attackList[currentTurn].Attack(hero);                   
                        }
                        return $"{attackList[currentTurn].DisplayName} dunked everyone!";
                    }
                    else
                    {
                        attackList[currentTurn].Attack(target);
                        return $"{attackList[currentTurn].DisplayName} dunked on {target.DisplayName}!";
                    }                  
                case "special":
                    return attackList[currentTurn].Special(target);
                case "magic":
                    attackList[currentTurn].Magic(target);
                    return $"{attackList[currentTurn].DisplayName} shot a three over {target.DisplayName}!";
                case "heal":
                    attackList[currentTurn].Heal(target);
                    return $"{attackList[currentTurn].DisplayName} gave a pep talk to {target.DisplayName}!";
                case "defend":
                    attackList[currentTurn].Defend(target);
                    return $"{attackList[currentTurn].DisplayName} set a screen for {target.DisplayName}!";
                default:
                    return "Nothing happened";
            }
        }

    }
}
