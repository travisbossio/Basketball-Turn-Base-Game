﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// Abstract unit class
    /// </summary>
    class Unit
    {
        protected int health;
        protected int speed;
        protected int physicalDefense;
        protected int magicDefense;
        protected int strength;
        protected int intelligence;
        protected string attackDisplay;
        private string name;
        protected bool defenseEnabled;
        protected bool isEnemy;
        private int listLocation;
        private string displayName;

        // default constructor
        public Unit()
        {
        }

        public bool DefendEnabled { get => defenseEnabled; set => defenseEnabled = value; }
        public int Health { get => health; set => health = value; }
        public int Speed { get => speed; set => speed = value; }
        public int PhysicalDefense { get => physicalDefense; set => physicalDefense = value; }
        public int MagicDefense { get => magicDefense; set => magicDefense = value; }
        public int Strength { get => strength; set => strength = value; }
        public int Intelligence { get => intelligence; set => intelligence = value; }
        public string AttackDisplay { get => attackDisplay; set => attackDisplay = value; }
        public string Name { get => name; set => name = value; }
        public bool IsEnemy { get => isEnemy; set => isEnemy = value; }
        public int ListLocation { get => listLocation; set => listLocation = value; }
        public string DisplayName { get => displayName; set => displayName = value; }

        /// <summary>
        /// method for units to preform attack
        /// </summary>
        /// <param name="target"></param>
        public virtual void Attack(Unit target)
        {
            // if block enabled halves the damage taken
            if (target.defenseEnabled)
            {
                target.Health = target.Health - ((strength - target.physicalDefense) / 2);
            }
            else
            {
                target.Health = target.Health - (strength - target.physicalDefense);
            }
            target.defenseEnabled = false;
        }

        /// <summary>
        /// method for units to preform special attack
        /// </summary>
        /// <param name="target"></param>
        public virtual string Special(Unit target)
        {
            target.Health = target.Health;
            target.defenseEnabled = false;

            return "";
        }

        /// <summary>
        /// method for units to preform healing
        /// </summary>
        /// <param name="target"></param>
        public virtual void Heal(Unit target)
        {
            target.Health = target.Health + 5;
            target.defenseEnabled = false;
        }

        /// <summary>
        /// method for units to preform magic attack
        /// </summary>
        /// <param name="target"></param>
        public virtual void Magic(Unit target)
        {
            // if block enabled halves the damage taken
            if (target.defenseEnabled)
            {
                target.Health = target.Health - ((intelligence - target.magicDefense) / 2);
            }
            else
            {
                target.Health = target.Health - (intelligence - target.magicDefense);
            }  
            target.defenseEnabled = false;
        }

        /// <summary>
        /// method for units to preform defend
        /// </summary>
        /// <param name="target"></param>
        public void Defend(Unit target)
        {
            target.defenseEnabled = true;
        }
    }
}
