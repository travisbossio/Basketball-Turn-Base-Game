﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tbossioFinalProject
{
    /// <summary>
    /// this is the ogre enemy class
    /// </summary>
    class Ogre : Enemy
    {
        /// <summary>
        /// initializes ogre character with following stats
        /// </summary>
        public Ogre()
        {
            this.health = 100;
            this.speed = 1;
            this.physicalDefense = 15;
            this.magicDefense = 15;
            this.strength = 40;
            this.intelligence = 5;
            this.Name = "Ogre";
            this.isEnemy = true;
            this.DisplayName = "Evil Center";
        }
    }
}
